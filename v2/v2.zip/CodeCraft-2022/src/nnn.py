changed_list = [1,2,3]
over_max_site_time_arr = []

while len(changed_list) != 0:
    over_max_site_time_arr.append(changed_list.pop())

aa = min(1,2,3)

print(over_max_site_time_arr)